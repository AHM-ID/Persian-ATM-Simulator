﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Diagnosis;

namespace DiagnosisTest
{
    [TestClass]
    public class Test
    {
        [TestMethod]
        public void TestDiagnosis()
        {
            var method = new Method();
            Assert.AreEqual("Integer number'", method.DiagnosisMethod("-4"));
            Assert.AreEqual("Integer number'", method.DiagnosisMethod("17.00"));
            Assert.AreEqual("decimal number", method.DiagnosisMethod("3.07"));
            Assert.AreEqual("Boolean", method.DiagnosisMethod("true"));
            Assert.AreEqual("string", method.DiagnosisMethod("ShahedUN"));
            Assert.AreEqual("string", method.DiagnosisMethod("@"));
        }
    }
}
