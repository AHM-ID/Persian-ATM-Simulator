﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diagnosis
{
    public class Method
    {
        /// <summary>
        /// this Method Will Check the Input Converting to some C# DataTypes Ability 
        /// </summary>
        /// <param name="input">User Input</param>
        /// <returns>if input Could Be Convert to int return Integer number.
        /// if input Could Be Convert to double return decimal number.
        /// if input Could Be Convert to boolean return Boolean.
        /// if input Could Be Convert to string or charachter return string.
        /// </returns>
        public string DiagnosisMethod(string input)
        {
            string Result = null;
            for (int i = input.Length - 1; i > 0; i--)
            {
                if (input[i] == '0')
                {
                    input = input.Substring(0, i);
                    i = input.Length;
                }
                else if (input[i] == '.')
                {
                    input = input.Substring(0, i);
                    i = input.Length;
                }
                else
                    break;
            }
            if (int.TryParse(input, out int Integer))
                Result = "Integer number'";
            else if (double.TryParse(input, out double Double))
                Result = "decimal number";
            else if (bool.TryParse(input, out bool Boolean))
                Result = "Boolean";
            else if (input.GetType() == typeof(string))
                Result = "string";

            return Result;
        }
    }
}
