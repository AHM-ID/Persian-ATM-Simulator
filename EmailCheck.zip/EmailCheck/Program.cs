﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailCheck
{
    public class Program
    {
        static void Main(string[] args)
        {
            var method = new ValidEmail();
            Console.WriteLine(method.ValidEmailCheck(Console.ReadLine()));
            Console.ReadKey();
        }
    }
}
