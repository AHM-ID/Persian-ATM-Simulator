﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailCheck
{
    public class ValidEmail
    {
        /// <summary>
        /// This Method Is Checking The Validation Of EmailAddress Which is Entered By User Input
        /// </summary>
        /// <param name="input">EmailAddress</param>
        /// <returns>
        /// Validation Condition Of Email Input. 
        /// if Email were Valid returns The Email Is Valid. else returns This Email Is Invalid.
        /// </returns>
        public string ValidEmailCheck(string input)
        {
            string Result = null;
            int Counter = input.Split('@').Length;
            if (Counter == 2)
            {
                input = input.Remove(0, input.IndexOf('@') + 1);
                if (input[0] != '.')
                {
                    Counter = input.Split('.').Length;
                    if (Counter > 1)
                        Result = "The Email Is Valid.";
                    else
                        Result = "This Email Is Invalid.";
                }
                else
                    Result = "This Email Is Invalid.";
            }
            else
                Result = "This Email Is Invalid.";

            return Result;
        }
    }
}
