﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using EmailCheck;

namespace EmailCheckTest
{
    [TestClass]
    public class Test
    {
        [TestMethod]
        public void EmailTest()
        {
            var method = new ValidEmail();
            Assert.AreEqual("This Email Is Invalid.", method.ValidEmailCheck("Amir.M@leki@gmail.com"));
            Assert.AreEqual("This Email Is Invalid.", method.ValidEmailCheck("Amir.Maleki.gmail.com"));
            Assert.AreEqual("This Email Is Invalid.", method.ValidEmailCheck("Amir.Maleki@gmailcom"));
            Assert.AreEqual("This Email Is Invalid.", method.ValidEmailCheck("Amir.Maleki@.com"));
            Assert.AreEqual("The Email Is Valid.", method.ValidEmailCheck("Amir.Maleki@gmail.com"));
            Assert.AreEqual("The Email Is Valid.", method.ValidEmailCheck("Amir.Maleki@shahed.ac.ir"));
        }
    }
}
