﻿using Stimulsoft.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class MainForm : Form
    {
        Machine machine;
        private static int _indexOfUser;
        public MainForm()
        {
            InitializeComponent();
            machine = new Machine();
            machine.ReadJson();
        }

        public int INDEXOFUSER
        {
            get
            {
                return _indexOfUser;
            }
            set
            {
                _indexOfUser = value;
            }
        }

        private void btnNewCustomer_Click(object sender, EventArgs e)
        {
            frmCustomerService frmCustomerService = new frmCustomerService();
            frmCustomerService.ShowDialog();
            if (frmCustomerService.DialogResult == DialogResult.OK)
            {
                machine.ReadJson();
                RefreshList();
                MessageBox.Show("کاربر باموفقیت ساخته شد", "عملیات موفق", MessageBoxButtons.OK);
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            bool Condition = true;
            this.Hide();
            frmLogin login = new frmLogin();
            while (Condition)
            {
                login.ShowDialog();
                if (login.DialogResult == DialogResult.OK)
                {
                    Condition = false;
                    this.Show();
                    Date.Text = "   " + DateTime.Now.ToShamsi();
                    Clock.Text = "   " + DateTime.Now.ToString("HH:mm:ss");
                    RefreshList();
                }
            }
        }

        public void RefreshList()
        {
            lblUserInfo.Items.Clear();
            List<User> customer = UserRepository.customersList.ToList();
            for (int i = 0; i < customer.Count; i++)
                lblUserInfo.Items.Add(i + 1 + ". " + customer[i].FirstName + " " + customer[i].LastName);
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            frmChangePassword password = new frmChangePassword();
            password.ShowDialog();
            if (password.DialogResult == DialogResult.OK)
            {
                machine.ReadJson();
                MessageBox.Show("عملیات با موفقیت انجام شد", "عملیات موفق", MessageBoxButtons.OK);
            }
        }

        private void btnCardToCard_Click(object sender, EventArgs e)
        {
            frmCardToCard cardToCard = new frmCardToCard();
            cardToCard.Operation = 0;
            cardToCard.index = INDEXOFUSER;
            cardToCard.ShowDialog();
            if (cardToCard.DialogResult == DialogResult.OK)
            {
                machine.ReadJson();
                MessageBox.Show("عملیات با موفقیت انجام شد", "عملیات موفق", MessageBoxButtons.OK);
            }
        }

        private void btnMobileCharge_Click(object sender, EventArgs e)
        {
            frmCardToCard cardToCard = new frmCardToCard();
            cardToCard.Operation = 1;
            cardToCard.index = INDEXOFUSER;
            cardToCard.ShowDialog();
            if (cardToCard.DialogResult == DialogResult.OK)
            {
                machine.ReadJson();
                MessageBox.Show("عملیات با موفقیت انجام شد", "عملیات موفق", MessageBoxButtons.OK);
            }
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            frmCustomerService service = new frmCustomerService();
            service.Index = INDEXOFUSER;
            service.Operation = 1;
            service.ShowDialog();
        }

        private void btnEditCustomer_Click(object sender, EventArgs e)
        {
            frmCustomerService service = new frmCustomerService();
            service.Index = INDEXOFUSER;
            service.Operation = 2;
            service.ShowDialog();
            if (service.DialogResult == DialogResult.OK)
            {
                machine.ReadJson();
                MessageBox.Show("ویرایش با موفقیت اعمال شد", "عملیات موفق", MessageBoxButtons.OK);
            }
        }

        private void btnWithdrawal_Click(object sender, EventArgs e)
        {
            frmMoneyTransfer transfer = new frmMoneyTransfer();
            transfer.Index = INDEXOFUSER;
            transfer.Operation = 0;
            transfer.ShowDialog();
            if (transfer.DialogResult == DialogResult.OK)
            {
                machine.ReadJson();
                MessageBox.Show($"عملیات با موفقیت انجام شد\n\n{UserRepository.customersList[INDEXOFUSER].AccountBalance} :مانده حساب", "عملیات موفق", MessageBoxButtons.OK);
            }
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            frmMoneyTransfer transfer = new frmMoneyTransfer();
            transfer.Index = INDEXOFUSER;
            transfer.Operation = 1;
            transfer.ShowDialog();
            if (transfer.DialogResult == DialogResult.OK)
            {
                machine.ReadJson();
                MessageBox.Show($"عملیات با موفقیت انجام شد\n\n{UserRepository.customersList[INDEXOFUSER].AccountBalance} :مانده حساب", "عملیات موفق", MessageBoxButtons.OK);
            }
        }

        private void btnRemoveAccount_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show($"{UserRepository.customersList[INDEXOFUSER].FirstName} {UserRepository.customersList[INDEXOFUSER].LastName} آیا از حذف حساب خود اطمینان دارید ؟", "حذف حساب کاربری", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Machine machine = new Machine();
                if (machine.RemoveAccount(UserRepository.customersList[INDEXOFUSER].AccountID))
                {
                    MessageBox.Show("حساب شما با موفقیت حذف شد");
                    this.Close();
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            Clock.Text = "   " + DateTime.Now.ToString("HH:mm:ss");
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            DataTable dtPrint = new DataTable();
            dtPrint.Columns.Add("FullName");
            dtPrint.Columns.Add("FatherName");
            dtPrint.Columns.Add("NationCode");
            dtPrint.Columns.Add("Phone");
            dtPrint.Columns.Add("BirthDate");
            dtPrint.Columns.Add("AccountID");
            foreach (var user in UserRepository.customersList)
            {
                dtPrint.Rows.Add
                    (
                    user.FirstName.ToString() + " " + user.LastName.ToString(),
                    user.FatherName.ToString() + " " + user.LastName.ToString(),
                    user.UserName.ToString(),
                    user.PhoneNumber.ToString(),
                    user.BirthDate.ToString(),
                    user.AccountID.ToString()
                    );
            }
            stiPrint.Load(Application.StartupPath + "/Report.mrt");
            stiPrint.RegData("DT", dtPrint);
            stiPrint.Show();
        }
    }
}
