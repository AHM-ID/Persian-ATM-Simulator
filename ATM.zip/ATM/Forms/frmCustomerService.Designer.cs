﻿namespace ATM
{
    partial class frmCustomerService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCustomerService));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblfrmCustomerService = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEmailAddress = new System.Windows.Forms.TextBox();
            this.rdMale = new System.Windows.Forms.RadioButton();
            this.rdFemale = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAccountID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtAccountBalance = new System.Windows.Forms.TextBox();
            this.btnSaveOrEdit = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBirthDate = new System.Windows.Forms.TextBox();
            this.btnDate = new System.Windows.Forms.Button();
            this.txtFatherName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtHomeAddress = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnProfilePhoto = new System.Windows.Forms.Button();
            this.pcProfile = new System.Windows.Forms.PictureBox();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtHomeNumber = new System.Windows.Forms.TextBox();
            this.txtPostCode = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcProfile)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.lblfrmCustomerService);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(792, 63);
            this.panel1.TabIndex = 0;
            // 
            // lblfrmCustomerService
            // 
            this.lblfrmCustomerService.Font = new System.Drawing.Font("B Yekan", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblfrmCustomerService.Location = new System.Drawing.Point(0, 0);
            this.lblfrmCustomerService.Name = "lblfrmCustomerService";
            this.lblfrmCustomerService.Size = new System.Drawing.Size(792, 63);
            this.lblfrmCustomerService.TabIndex = 1;
            this.lblfrmCustomerService.Text = "افزودن کاربر جدید";
            this.lblfrmCustomerService.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("B Yekan", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(97, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "نام :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "نام خانوادگی :";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(140, 87);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(264, 30);
            this.txtFirstName.TabIndex = 0;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(140, 136);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(264, 30);
            this.txtLastName.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 502);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "کلمه عبور :";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(140, 499);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(264, 30);
            this.txtPassword.TabIndex = 6;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 290);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "آدرس ایمیل :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(75, 606);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "جنسیت :";
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Location = new System.Drawing.Point(140, 287);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(264, 30);
            this.txtEmailAddress.TabIndex = 4;
            // 
            // rdMale
            // 
            this.rdMale.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdMale.BackColor = System.Drawing.Color.MidnightBlue;
            this.rdMale.Font = new System.Drawing.Font("Mitra", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.rdMale.ForeColor = System.Drawing.Color.Gold;
            this.rdMale.Location = new System.Drawing.Point(140, 592);
            this.rdMale.Name = "rdMale";
            this.rdMale.Size = new System.Drawing.Size(90, 48);
            this.rdMale.TabIndex = 12;
            this.rdMale.TabStop = true;
            this.rdMale.Text = "مرد";
            this.rdMale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdMale.UseVisualStyleBackColor = false;
            this.rdMale.CheckedChanged += new System.EventHandler(this.rdMale_CheckedChanged);
            // 
            // rdFemale
            // 
            this.rdFemale.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdFemale.BackColor = System.Drawing.Color.MidnightBlue;
            this.rdFemale.Font = new System.Drawing.Font("Mitra", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.rdFemale.ForeColor = System.Drawing.Color.Gold;
            this.rdFemale.Location = new System.Drawing.Point(236, 592);
            this.rdFemale.Name = "rdFemale";
            this.rdFemale.Size = new System.Drawing.Size(90, 48);
            this.rdFemale.TabIndex = 12;
            this.rdFemale.TabStop = true;
            this.rdFemale.Text = "زن";
            this.rdFemale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdFemale.UseVisualStyleBackColor = false;
            this.rdFemale.CheckedChanged += new System.EventHandler(this.rdFemale_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(441, 402);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 23);
            this.label6.TabIndex = 13;
            this.label6.Text = "تاریخ تولد :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(47, 398);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 23);
            this.label7.TabIndex = 14;
            this.label7.Text = "شماره حساب :";
            // 
            // txtAccountID
            // 
            this.txtAccountID.Location = new System.Drawing.Point(140, 395);
            this.txtAccountID.Name = "txtAccountID";
            this.txtAccountID.ReadOnly = true;
            this.txtAccountID.Size = new System.Drawing.Size(264, 30);
            this.txtAccountID.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(52, 450);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 23);
            this.label8.TabIndex = 16;
            this.label8.Text = "مانده حساب :";
            // 
            // txtAccountBalance
            // 
            this.txtAccountBalance.Location = new System.Drawing.Point(140, 447);
            this.txtAccountBalance.Name = "txtAccountBalance";
            this.txtAccountBalance.ReadOnly = true;
            this.txtAccountBalance.Size = new System.Drawing.Size(264, 30);
            this.txtAccountBalance.TabIndex = 15;
            // 
            // btnSaveOrEdit
            // 
            this.btnSaveOrEdit.AutoSize = true;
            this.btnSaveOrEdit.BackColor = System.Drawing.Color.ForestGreen;
            this.btnSaveOrEdit.Font = new System.Drawing.Font("B Titr", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSaveOrEdit.ForeColor = System.Drawing.Color.Transparent;
            this.btnSaveOrEdit.Location = new System.Drawing.Point(591, 588);
            this.btnSaveOrEdit.Name = "btnSaveOrEdit";
            this.btnSaveOrEdit.Size = new System.Drawing.Size(189, 57);
            this.btnSaveOrEdit.TabIndex = 13;
            this.btnSaveOrEdit.Text = "ذخیره";
            this.btnSaveOrEdit.UseVisualStyleBackColor = false;
            this.btnSaveOrEdit.Click += new System.EventHandler(this.btnSaveOrEdit_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 237);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 23);
            this.label9.TabIndex = 19;
            this.label9.Text = "نام کاربری (کدملی) :";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(140, 234);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(264, 30);
            this.txtUserName.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(136, 535);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(268, 48);
            this.label10.TabIndex = 21;
            this.label10.Text = "کلمه عبور باید شامل حروف بزرگ و کوچک و سمبل و به طول بیشتر از 8 کاراکتر باشد.";
            // 
            // txtBirthDate
            // 
            this.txtBirthDate.Location = new System.Drawing.Point(519, 398);
            this.txtBirthDate.Name = "txtBirthDate";
            this.txtBirthDate.ReadOnly = true;
            this.txtBirthDate.Size = new System.Drawing.Size(161, 30);
            this.txtBirthDate.TabIndex = 22;
            // 
            // btnDate
            // 
            this.btnDate.Location = new System.Drawing.Point(682, 398);
            this.btnDate.Name = "btnDate";
            this.btnDate.Size = new System.Drawing.Size(98, 30);
            this.btnDate.TabIndex = 9;
            this.btnDate.Text = "انتخاب";
            this.btnDate.UseVisualStyleBackColor = true;
            this.btnDate.Click += new System.EventHandler(this.btnDate_Click);
            // 
            // txtFatherName
            // 
            this.txtFatherName.Location = new System.Drawing.Point(140, 184);
            this.txtFatherName.Name = "txtFatherName";
            this.txtFatherName.Size = new System.Drawing.Size(264, 30);
            this.txtFatherName.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(79, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 23);
            this.label11.TabIndex = 24;
            this.label11.Text = "نام پدر :";
            // 
            // txtHomeAddress
            // 
            this.txtHomeAddress.Location = new System.Drawing.Point(516, 499);
            this.txtHomeAddress.Multiline = true;
            this.txtHomeAddress.Name = "txtHomeAddress";
            this.txtHomeAddress.Size = new System.Drawing.Size(264, 80);
            this.txtHomeAddress.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(461, 502);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 23);
            this.label12.TabIndex = 26;
            this.label12.Text = "آدرس :";
            // 
            // btnProfilePhoto
            // 
            this.btnProfilePhoto.BackColor = System.Drawing.Color.OrangeRed;
            this.btnProfilePhoto.Font = new System.Drawing.Font("B Yekan", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnProfilePhoto.ForeColor = System.Drawing.Color.White;
            this.btnProfilePhoto.Location = new System.Drawing.Point(534, 300);
            this.btnProfilePhoto.Name = "btnProfilePhoto";
            this.btnProfilePhoto.Size = new System.Drawing.Size(215, 35);
            this.btnProfilePhoto.TabIndex = 7;
            this.btnProfilePhoto.Text = "انتخاب تصویر";
            this.btnProfilePhoto.UseVisualStyleBackColor = false;
            this.btnProfilePhoto.Click += new System.EventHandler(this.btnProfilePhoto_Click);
            // 
            // pcProfile
            // 
            this.pcProfile.Image = global::ATM.Properties.Resources.ProfilePhoto;
            this.pcProfile.Location = new System.Drawing.Point(534, 87);
            this.pcProfile.Name = "pcProfile";
            this.pcProfile.Size = new System.Drawing.Size(215, 207);
            this.pcProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcProfile.TabIndex = 27;
            this.pcProfile.TabStop = false;
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(140, 341);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(264, 30);
            this.txtPhoneNumber.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(56, 344);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 23);
            this.label13.TabIndex = 29;
            this.label13.Text = "تلفن همراه :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(440, 344);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 23);
            this.label14.TabIndex = 31;
            this.label14.Text = "تلفن ثابت :";
            // 
            // txtHomeNumber
            // 
            this.txtHomeNumber.Location = new System.Drawing.Point(516, 341);
            this.txtHomeNumber.Name = "txtHomeNumber";
            this.txtHomeNumber.Size = new System.Drawing.Size(264, 30);
            this.txtHomeNumber.TabIndex = 8;
            // 
            // txtPostCode
            // 
            this.txtPostCode.Location = new System.Drawing.Point(516, 447);
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(264, 30);
            this.txtPostCode.TabIndex = 10;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(445, 450);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 23);
            this.label15.TabIndex = 33;
            this.label15.Text = "کد پستی :";
            // 
            // btnPrint
            // 
            this.btnPrint.AutoSize = true;
            this.btnPrint.BackColor = System.Drawing.Color.ForestGreen;
            this.btnPrint.Font = new System.Drawing.Font("B Titr", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnPrint.ForeColor = System.Drawing.Color.Transparent;
            this.btnPrint.Location = new System.Drawing.Point(477, 587);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(108, 58);
            this.btnPrint.TabIndex = 34;
            this.btnPrint.Text = "چاپ";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // frmCustomerService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(792, 647);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtPostCode);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtHomeNumber);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtPhoneNumber);
            this.Controls.Add(this.btnProfilePhoto);
            this.Controls.Add(this.pcProfile);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtHomeAddress);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtFatherName);
            this.Controls.Add(this.btnDate);
            this.Controls.Add(this.txtBirthDate);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnSaveOrEdit);
            this.Controls.Add(this.txtAccountBalance);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtAccountID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rdFemale);
            this.Controls.Add(this.rdMale);
            this.Controls.Add(this.txtEmailAddress);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("B Yekan", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "frmCustomerService";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "افزودن کاربر جدید";
            this.Load += new System.EventHandler(this.frmCustomerService_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcProfile)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblfrmCustomerService;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEmailAddress;
        private System.Windows.Forms.RadioButton rdMale;
        private System.Windows.Forms.RadioButton rdFemale;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAccountID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtAccountBalance;
        private System.Windows.Forms.Button btnSaveOrEdit;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtBirthDate;
        private System.Windows.Forms.Button btnDate;
        private System.Windows.Forms.TextBox txtFatherName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtHomeAddress;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pcProfile;
        private System.Windows.Forms.Button btnProfilePhoto;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtHomeNumber;
        private System.Windows.Forms.TextBox txtPostCode;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnPrint;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}