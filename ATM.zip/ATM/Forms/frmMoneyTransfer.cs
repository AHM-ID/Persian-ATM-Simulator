﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class frmMoneyTransfer : Form
    {
        Machine machine;
        public int Index;
        public int Operation;
        private static int WrongPassRepeat = 0;
        public frmMoneyTransfer()
        {
            InitializeComponent();
            machine = new Machine();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (NullInput())
            {
                if (ValidateInputs())
                {
                    if (Operation == 0)
                    {
                        if (UserRepository.customersList[Index].AccountBalance >= Convert.ToUInt64(txtAmount.Text))
                            if (machine.WithdrawalMoney(UserRepository.customersList[Index].AccountID, Convert.ToUInt64(txtAmount.Text)))
                                DialogResult = DialogResult.OK;
                        else
                            MessageBox.Show("موجودی شما کافی نیست");
                    }
                    else if (Operation == 1)
                        if (machine.DepositMoney(UserRepository.customersList[Index].AccountID, Convert.ToUInt64(txtAmount.Text)))
                            DialogResult = DialogResult.OK;
                }
            }
        }

        public bool ValidateInputs()
        {
            if (UserRepository.customersList[Index].AccountID == txtAccountID.Text)
            {
                if (UserRepository.customersList[Index].Password == txtPassword.Text)
                {
                    return true;
                }
                else
                {
                    WrongPassRepeat++;
                    if (WrongPassRepeat == 3)
                    {
                        if (machine.RemoveAccount(UserRepository.customersList[Index].AccountID))
                        {
                            MessageBox.Show("حساب شما بلوکه شد", "هشدار بلوک حساب");
                            System.Environment.Exit(0);
                        }
                        return false;
                    }
                    else
                    {
                        MessageBox.Show("لطفا رمزعبور خود را به درستی وارد کنید");
                        return false;
                    }
                }
            }
            else
            {
                MessageBox.Show("شماره حساب خود را به دقت وارد کنید");
                return false;
            }
        }

        public bool NullInput()
        {
            if (txtAccountID.Text != "")
            {
                if (txtAmount.Text != "")
                {
                    if (txtPassword.Text != "")
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("لطفا کلمه عبور را وارد کنید");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("لطفا مبلغ را وارد کنید");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("لطفا شماره حساب خود را وارد کنید");
                return false;
            }
        }

        private void frmMoneyTransfer_Load(object sender, EventArgs e)
        {
            txtRemainingMoney.ReadOnly = true;
            if (Operation == 1)
            {
                this.Text = "واریز وجه";
                btnSubmit.Text = "واریز";
                lblTopForm.Text = "واریز وجه";
            }
        }

        private void txtAccountID_TextChanged(object sender, EventArgs e)
        {
            if (UserRepository.customersList[Index].AccountID == txtAccountID.Text)
                txtRemainingMoney.Text = UserRepository.customersList[Index].AccountBalance.ToString();
            else
                txtRemainingMoney.Text = null;
        }
    }
}
