﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.IO;

namespace ATM
{
    public partial class frmChangePassword : Form
    {
        Machine machine;
        MainForm form;
        int index;
        private static int WrongPassRepeat = 0;
        public frmChangePassword()
        {
            InitializeComponent();
            form = new MainForm();
            machine = new Machine();
            index = form.INDEXOFUSER;
        }

        private void btnUpdatePassword_Click(object sender, EventArgs e)
        {
            if (NullInputs())
            {
                if (ValidateInputs())
                {
                    UserRepository.customersList[index].Password = txtNewPass.Text;
                    string json = JsonConvert.SerializeObject(UserRepository.customersList.ToArray());
                    File.WriteAllText(Application.StartupPath.ToString() + "Data.txt", json);
                    DialogResult = DialogResult.OK;
                }
            }
        }

        public bool ValidateInputs()
        {
            if (UserRepository.customersList[index].Password == txtOldPass.Text)
            {
                if (txtNewPass.Text != txtOldPass.Text)
                {
                    if (machine.PasswordSecurity(txtNewPass.Text))
                    {
                        if (txtConfirmNewPassword.Text == txtNewPass.Text)
                        {
                            return true;
                        }
                        else
                        {
                            MessageBox.Show("تکرار رمز را با دقت وارد کنید", "خطا !!!");
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("امنیت رمز پایین است رمز دیگری انتخاب کنید\n\nکلمه عبور باید شامل حروف بزرگ و کوچک و سمبل و به طول بیشتر از 8 کاراکتر باشد.", "رمز ناامن");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("لطفا رمز جدید انتخاب کنید\n\nرمز قبلا وارد شده", "خطا !!!");
                    return false;
                }
            }
            else
            {
                WrongPassRepeat++;
                if (WrongPassRepeat == 3)
                {
                    if (machine.RemoveAccount(UserRepository.customersList[index].AccountID))
                    {
                        MessageBox.Show("حساب شما بلوکه شد", "هشدار بلوک حساب");
                        System.Environment.Exit(0);
                    }
                }
                else
                    MessageBox.Show("رمز عبور اشتباه است.", "خطا !!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        public bool NullInputs()
        {
            if (txtOldPass.Text != "")
            {
                if (txtNewPass.Text != "")
                {
                    if (txtConfirmNewPassword.Text != "")
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("لطفا تایید کلمه عبور را وارد کنید");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("لطفا کلمه عبور را وارد کنید");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("لطفا کلمه عبور پیشین را وارد کنید");
                return false;
            }
        }
    }
}
