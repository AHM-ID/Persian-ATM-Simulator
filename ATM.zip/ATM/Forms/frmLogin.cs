﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class frmLogin : Form
    {
        Machine machine;
        private static int WrongPassRepeat = 0;
        public frmLogin()
        {
            InitializeComponent();
            machine = new Machine();
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            frmCustomerService customerService = new frmCustomerService();
            customerService.ShowDialog();
            if (customerService.DialogResult == DialogResult.OK)
                machine.ReadJson();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (UserRepository.customersList.Exists(user => user.UserName == txtNationalCode.Text))
            {
                int index = UserRepository.customersList.FindIndex(user => user.UserName == txtNationalCode.Text);
                if (UserRepository.customersList[index].Password == txtPassword.Text)
                {
                    MainForm form = new MainForm();
                    form.INDEXOFUSER = index;
                    MessageBox.Show($"{UserRepository.customersList[index].FirstName} {UserRepository.customersList[index].LastName} خوش آمدید", "ورود موفق");
                    DialogResult = DialogResult.OK;
                }
                else
                {
                    WrongPassRepeat++;
                    if (WrongPassRepeat == 3)
                    {
                        Machine machine = new Machine();
                        if (machine.RemoveAccount(UserRepository.customersList[index].AccountID))
                        {
                            MessageBox.Show("حساب شما بلوکه شد", "هشدار بلوک حساب");
                            System.Environment.Exit(0);
                        }
                    }
                    else
                        MessageBox.Show("رمز عبور اشتباه است", "خطا !!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.Cancel;
                }
            }
            else
            {
                MessageBox.Show("نام کاربری اشتباه است", "خطا !!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.Cancel;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
