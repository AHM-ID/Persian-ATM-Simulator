﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ATM
{
    public partial class frmCustomerService : Form
    {
        Machine user;
        public int Operation;
        public int Index;
        public frmCustomerService()
        {
            InitializeComponent();
            user = new Machine();
            user.ID();
        }

        private bool ValidateInputs()
        {
            if (txtFirstName.Text != "")
            {
                if (txtLastName.Text != "")
                {
                    if (txtFatherName.Text != "")
                    {
                        if (txtUserName.Text != "")
                        {
                            if (txtPhoneNumber.Text != "")
                            {
                                if (txtHomeNumber.Text != "")
                                {
                                    if (txtPassword.Text != "")
                                    {
                                        if (txtEmailAddress.Text != "")
                                        {
                                            if (txtBirthDate.Text != "")
                                            {
                                                if (txtPostCode.Text != "")
                                                {
                                                    if (rdMale.Checked == true || rdFemale.Checked == true)
                                                        return true;
                                                    else
                                                    {
                                                        MessageBox.Show("لطفا جنسیت را انتخاب کنید");
                                                        return false;
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("لطفا کد پستی خود را وارد کنید");
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("لطفا تاریخ تولد را انتخاب کنید");
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("لطفا ایمیل خود را وارد کنید");
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("لطفا کلمه عبور خود را وارد کنید");
                                        return false;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("لطفا شماره تلفن ثابت خود را وارد کنید");
                                    return false;
                                }
                            }
                            else
                            {
                                MessageBox.Show("لطفا شماره تلفن همراه خود را وارد کنید");
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show("لطفا نام کاربری خود را وارد کنید");
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("لطفا نام پدر خود را وارد کنید");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("لطفا نام خانوادگی خود را وارد کنید");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("لطفا نام خود را وارد کنید");
                return false;
            }
        }

        public void ProfilePictureSet()
        {
            string ImageName = Guid.NewGuid().ToString() + Path.GetExtension(pcProfile.ImageLocation);
            string Imagepath = Application.StartupPath + "/Images/";
            if (!Directory.Exists(Imagepath))
                Directory.CreateDirectory(Imagepath);
            pcProfile.Image.Save(Imagepath + ImageName);
            user.ProfilePhoto = ImageName;
        }

        public void SaveCustomer()
        {
            if (ValidateInputs())
            {
                if (txtUserName.TextLength == 10)
                {
                    if (!UserRepository.customersList.Exists(user => user.UserName == txtUserName.Text))
                    {
                        if (user.PasswordSecurity(txtPassword.Text))
                        {
                            if (user.EmailCheck(txtEmailAddress.Text))
                            {
                                if (txtPhoneNumber.TextLength == 11)
                                {
                                    if (!UserRepository.customersList.Exists(user => user.PhoneNumber == txtPhoneNumber.Text))
                                    {
                                        user.FirstName = txtFirstName.Text;
                                        user.LastName = txtLastName.Text;
                                        user.FatherName = txtFatherName.Text;
                                        user.UserName = txtUserName.Text;
                                        user.Password = txtPassword.Text;
                                        user.BirthDate = txtBirthDate.Text;
                                        user.PhoneNumber = txtPhoneNumber.Text;
                                        user.HomeNumber = txtHomeNumber.Text;
                                        user.EmailAddress = txtEmailAddress.Text;
                                        user.AccountOpen = DateTime.Now.ToShamsi();
                                        user.PostCode = txtPostCode.Text;
                                        user.HomeAddress = txtHomeAddress.Text;
                                        if (rdMale.Checked == true)
                                            user.Gender = GenderType.Male;
                                        else
                                            user.Gender = GenderType.Female;
                                        ProfilePictureSet();
                                        UserRepository.customersList.Add(user);
                                        user.WriteJson();
                                        DialogResult = DialogResult.OK;
                                    }
                                    else
                                        MessageBox.Show("شخص دیگری با این شماره همراه ثبت نام کرده است\nلطفا شماره تلفن همراه خود را به درستی وارد کنید", "شماره تلفن همراه تکراری");
                                }
                                else
                                    MessageBox.Show("لطفا شماره تلفن همراه خود را به درستی وارد کنید", "شماره همراه نامعتبر");
                            }
                            else
                                MessageBox.Show("لطفا ایمیل خود را به درستی وارد کنید", "ایمیل نامعتبر");
                        }
                        else
                        {
                            label10.Visible = true;
                            MessageBox.Show("امنیت رمز پایین است رمز دیگری انتخاب کنید", "رمز ناامن");
                        }
                    }
                    else
                        MessageBox.Show("حساب کاربری دیگری با این کد ملی ثبت شده است\nلطفا از درستی نام کاربری خود اطمینان حاصل نمایید");
                }
                else
                    MessageBox.Show("لطفا نام کاربری خود را به درستی وارد کنید", "نام کاربری نامعتبر");
            }
        }

        public void EditCustomer()
        {
            if (ValidateInputs())
            {
                if (txtUserName.TextLength == 10)
                {
                    if (CheckUserName())
                    {
                        if (user.PasswordSecurity(txtPassword.Text))
                        {
                            if (user.EmailCheck(txtEmailAddress.Text))
                            {
                                if (txtPhoneNumber.TextLength == 11)
                                {
                                    if (CheckPhoneNumber())
                                    {
                                        user.FirstName = txtFirstName.Text;
                                        user.LastName = txtLastName.Text;
                                        user.FatherName = txtFatherName.Text;
                                        user.UserName = txtUserName.Text;
                                        user.Password = txtPassword.Text;
                                        user.BirthDate = txtBirthDate.Text;
                                        user.PhoneNumber = txtPhoneNumber.Text;
                                        user.HomeNumber = txtHomeNumber.Text;
                                        user.EmailAddress = txtEmailAddress.Text;
                                        user.PostCode = txtPostCode.Text;
                                        user.HomeAddress = txtHomeAddress.Text;
                                        user.AccountID = UserRepository.customersList[Index].AccountID;
                                        user.AccountOpen = UserRepository.customersList[Index].AccountOpen;
                                        if (rdMale.Checked == true)
                                            user.Gender = GenderType.Male;
                                        else
                                            user.Gender = GenderType.Female;
                                        ProfilePictureSet();
                                        UserRepository.customersList[Index] = user;
                                        user.WriteJson();
                                        DialogResult = DialogResult.OK;
                                    }
                                    else
                                        MessageBox.Show("شخص دیگری با این شماره همراه ثبت نام کرده است\nلطفا شماره تلفن همراه خود را به درستی وارد کنید", "شماره تلفن همراه تکراری");
                                }
                                else
                                    MessageBox.Show("لطفا شماره تلفن همراه خود را به درستی وارد کنید", "شماره همراه نامعتبر");
                            }
                            else
                                MessageBox.Show("لطفا ایمیل خود را به درستی وارد کنید", "ایمیل نامعتبر");
                        }
                    }
                    else
                        MessageBox.Show("حساب کاربری دیگری با این کد ملی ثبت شده است\nلطفا از درستی نام کاربری خود اطمینان حاصل نمایید");
                }
                else
                    MessageBox.Show("لطفا نام کاربری خود را به درستی وارد کنید", "نام کاربری نامعتبر");
            }
        }

        private bool CheckUserName()
        {
            if (UserRepository.customersList[Index].UserName == txtUserName.Text)
                return true;
            else if (!UserRepository.customersList.Exists(user => user.UserName == txtUserName.Text))
                return true;
            else
                return false;
        }

        public bool CheckPhoneNumber()
        {
            if (UserRepository.customersList[Index].PhoneNumber == txtPhoneNumber.Text)
                return true;
            else if (!UserRepository.customersList.Exists(user => user.PhoneNumber == txtPhoneNumber.Text))
                return true;
            else
                return false;
        }

        private void btnSaveOrEdit_Click(object sender, EventArgs e)
        {
            if (Operation == 0)
                SaveCustomer();
            else if (Operation == 1)
                DialogResult = DialogResult.OK;
            else if (Operation == 2)
                EditCustomer();
        }

        private void rdMale_CheckedChanged(object sender, EventArgs e)
        {
            if (Operation != 1)
            {
                rdMale.BackColor = Color.DarkRed;
                rdMale.ForeColor = Color.White;
                rdFemale.BackColor = Color.MidnightBlue;
                rdFemale.ForeColor = Color.Gold;
            }
        }

        private void rdFemale_CheckedChanged(object sender, EventArgs e)
        {
            if (Operation != 1)
            {
                rdMale.BackColor = Color.MidnightBlue;
                rdMale.ForeColor = Color.Gold;
                rdFemale.BackColor = Color.DarkRed;
                rdFemale.ForeColor = Color.White;
            }
        }

        private void frmCustomerService_Load(object sender, EventArgs e)
        {
            label10.Visible = false;
            if (Operation == 0)
            {
                btnPrint.Visible = false;
                txtAccountID.Text = user.NewAccountID.ToString();
                txtAccountBalance.Text = user.AccountBalance.ToString();
            }
            else if (Operation == 1)
            {
                btnSaveOrEdit.Text = "تایید";
                lblfrmCustomerService.Text = "اطلاعات کاربری";
                this.Text = "فرم اطلاعات";
                label3.Text = "تاریخ افتتاح حساب :";
                label3.Location = new Point(22, 502);
                User Temp = UserRepository.customersList[Index];
                txtFirstName.Text = Temp.FirstName;
                txtLastName.Text = Temp.LastName;
                txtFatherName.Text = Temp.FatherName;
                txtUserName.Text = Temp.UserName;
                txtPassword.Text = Temp.AccountOpen.ToString();
                txtPhoneNumber.Text = Temp.PhoneNumber;
                txtHomeNumber.Text = Temp.HomeNumber;
                txtAccountBalance.Text = Temp.AccountBalance.ToString();
                txtEmailAddress.Text = Temp.EmailAddress;
                txtAccountID.Text = Temp.AccountID;
                txtBirthDate.Text = Temp.BirthDate;
                pcProfile.ImageLocation = Application.StartupPath + "/Images/" + Temp.ProfilePhoto;
                if (Temp.Gender == GenderType.Male)
                {
                    rdMale.BackColor = Color.Red;
                    rdFemale.BackColor = Color.Silver;
                    rdMale.Checked = true;
                }
                else
                {
                    rdFemale.BackColor = Color.Red;
                    rdMale.BackColor = Color.Silver;
                    rdFemale.Checked = true;
                }
                txtPostCode.Text = Temp.PostCode;
                txtHomeAddress.Text = Temp.HomeAddress;
                txtFirstName.ReadOnly = true;
                txtLastName.ReadOnly = true;
                txtFatherName.ReadOnly = true;
                txtUserName.ReadOnly = true;
                txtPassword.ReadOnly = true;
                txtPhoneNumber.ReadOnly = true;
                txtHomeNumber.ReadOnly = true;
                txtEmailAddress.ReadOnly = true;
                btnDate.Visible = false;
                btnProfilePhoto.Visible = false;
                rdMale.Enabled = false;
                rdFemale.Enabled = false;
                txtHomeAddress.ReadOnly = true;
                txtPostCode.ReadOnly = true;
            }
            else if (Operation == 2)
            {
                btnPrint.Visible = false;
                btnSaveOrEdit.Text = "ویرایش";
                lblfrmCustomerService.Text = "ویرایش اطلاعات کاربری";
                this.Text = "فرم ویرایش اطلاعات";
                User Temp = UserRepository.customersList[Index];
                txtFirstName.Text = Temp.FirstName;
                txtLastName.Text = Temp.LastName;
                txtFatherName.Text = Temp.FatherName;
                txtUserName.Text = Temp.UserName;
                txtPassword.Text = Temp.Password;
                txtPhoneNumber.Text = Temp.PhoneNumber;
                txtHomeNumber.Text = Temp.HomeNumber;
                txtAccountBalance.Text = Temp.AccountBalance.ToString();
                txtEmailAddress.Text = Temp.EmailAddress;
                txtAccountID.Text = Temp.AccountID;
                txtBirthDate.Text = Temp.BirthDate;
                pcProfile.ImageLocation = Application.StartupPath + "/Images/" + Temp.ProfilePhoto;
                if (Temp.Gender == GenderType.Male)
                    rdMale.Checked = true;
                else
                    rdFemale.Checked = true;
                txtPostCode.Text = Temp.PostCode;
                txtHomeAddress.Text = Temp.HomeAddress;
                txtPassword.Visible = false;
                label3.Visible = false;
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            label10.Visible = false;
        }

        private void btnDate_Click(object sender, EventArgs e)
        {
            frmPersianCalendar calendar = new frmPersianCalendar();
            calendar.loc = btnProfilePhoto.Location;
            calendar.ShowDialog();
            if (calendar.DialogResult == DialogResult.OK)
                txtBirthDate.Text = calendar.txtDate;
        }

        private void btnProfilePhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog Dialog = new OpenFileDialog();
            if (Dialog.ShowDialog() == DialogResult.OK)
                pcProfile.ImageLocation = Dialog.FileName;
        }

        Bitmap bitmap;

        private void btnPrint_Click(object sender, EventArgs e)
        {
            Graphics grc = this.CreateGraphics();
            Size size = this.Size;
            bitmap = new Bitmap(size.Width, size.Height, grc);
            Graphics memoryGraphics = Graphics.FromImage(bitmap);
            memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, size);
            printDocument1.DefaultPageSettings.Landscape = true;
            printDocument1.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);
            printDocument1.DefaultPageSettings.PaperSize = new PaperSize("MyPaper", 900, 1100);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
            if (printPreviewDialog1.DialogResult == DialogResult.OK)
                printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bitmap, 0, 0);
        }
    }
}
