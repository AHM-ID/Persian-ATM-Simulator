﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ATM
{
    public partial class frmPersianCalendar : Form
    {
        public string txtDate;
        public Point loc;

        public frmPersianCalendar()
        {
            InitializeComponent();
        }

        private void PersianCalender_SelectedDateChanged(DateTime selectedDateTime, BehComponents.PersianDateTime selectedPersianDateTime)
        {
            txtDate = PersianCalender.GetSelectedDateInPersianDateTime().ToShortDateString();
        }

        private void PC_Load(object sender, EventArgs e)
        {
            this.Location = new Point(loc.X + 30, loc.Y);
            txtDate = PersianCalender.GetSelectedDateInPersianDateTime().ToShortDateString();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}
