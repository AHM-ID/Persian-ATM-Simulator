﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class frmCardToCard : Form
    {
        Machine machine;
        public int Operation;
        public int index;
        private static int WrongPassRepeat = 0;
        public frmCardToCard()
        {
            InitializeComponent();
            machine = new Machine();
            machine.ReadJson();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Operation == 0)
            {
                if (NullInput())
                {
                    if (txtDestinationCard.Text != "")
                    {
                        if (ValidateInputs())
                        {
                            if (txtUserCard.Text == UserRepository.customersList[index].AccountID)
                            {
                                if (UserRepository.customersList.Exists(user => user.AccountID==txtDestinationCard.Text))
                                {
                                    if (txtUserCard.Text != txtDestinationCard.Text)
                                    {
                                        if (machine.CardToCard(txtUserCard.Text, txtDestinationCard.Text, Convert.ToUInt64(txtSerial.Text)))
                                            DialogResult = DialogResult.OK;
                                    }
                                    else
                                        MessageBox.Show("هردو شماره حساب یکسان است\nشما نمیتوانید با خودتان کارت به کارت انجام دهید");
                                }
                                else
                                    MessageBox.Show("لطفا شماره حساب مقصد را به درستی وارد کنید");
                            }
                            else
                                MessageBox.Show("شماره حساب متعلق به شما نیست");
                        }
                    }
                    else
                        MessageBox.Show("لطفا شماره حساب مقصد را وارد کنید");
                }
            }
            else if (Operation == 1)
            {
                if (NullInput())
                {
                    if (ValidateInputs())
                    {
                        string Res = machine.MobileCharge(txtUserCard.Text, Convert.ToUInt64(txtSerial.Text));
                        MessageBox.Show($": کد شارژ شما\n\n{Res}", "خرید شارژ");
                        DialogResult = DialogResult.OK;
                    }
                }
            }
        }

        private void txtUserCard_TextChanged(object sender, EventArgs e)
        {
            if (txtUserCard.Text == UserRepository.customersList[index].AccountID)
            {
                txtBalance.Text = UserRepository.customersList[index].AccountBalance.ToString();
            }
            else
                txtBalance.Text = null;
        }

        public bool ValidateInputs()
        {
            if (UserRepository.customersList.Exists(user => user.AccountID == txtUserCard.Text))
            {
                if (UserRepository.customersList[index].AccountID == txtUserCard.Text)
                {
                    if (UserRepository.customersList[index].Password == txtPassword.Text)
                    {
                        if (UserRepository.customersList[index].AccountBalance >= Convert.ToUInt64(txtSerial.Text))
                            return true;
                        else
                        {
                            MessageBox.Show("موجودی شما کافی نیست");
                            return false;
                        }
                    }
                    else
                    {
                        WrongPassRepeat++;
                        if (WrongPassRepeat == 3)
                        {
                            if (machine.RemoveAccount(txtUserCard.Text))
                            {
                                MessageBox.Show("حساب شما بلوکه شد", "هشدار بلوک حساب");
                                System.Environment.Exit(0);
                            }
                        }
                        else
                            MessageBox.Show("لطفا رمزعبور خود را به درستی وارد کنید");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("شماره حساب متعلق به شما نیست");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("لطفا شماره حساب خود را به درستی وارد کنید");
                return false;
            }
        }

        public bool NullInput()
        {
            if (txtUserCard.Text != "")
            {
                if (txtPassword.Text != "")
                {
                    if (txtSerial.Text != "")
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("لطفا مبلغ را وارد کنید");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("لطفا کلمه عبور را وارد کنید");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("لطفا شماره حساب خود را وارد کنید");
                return false;
            }
        }

        private void frmCardToCard_Load(object sender, EventArgs e)
        {
            if (Operation == 1)
            {
                this.Text = "خرید شارژ";
                label4.Visible = false;
                txtDestinationCard.Visible = false;
                name.Visible = false;
                txtDestName.Visible = false;
                lblTopForm.Text = "خرید شارژ";
            }
        }

        private void txtDestinationCard_TextChanged(object sender, EventArgs e)
        {
            if (UserRepository.customersList.Exists(user => user.AccountID == txtDestinationCard.Text))
            {
                int number = UserRepository.customersList.FindIndex(user => user.AccountID == txtDestinationCard.Text);
                txtDestName.Text = UserRepository.customersList[number].FirstName + " " + UserRepository.customersList[number].LastName;
            }
            else
                txtDestName.Text = null;
        }
    }
}
