﻿namespace ATM
{
    partial class frmCardToCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUserCard = new System.Windows.Forms.TextBox();
            this.txtDestinationCard = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtSerial = new System.Windows.Forms.TextBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDestName = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTopForm = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtUserCard
            // 
            this.txtUserCard.Location = new System.Drawing.Point(117, 55);
            this.txtUserCard.Name = "txtUserCard";
            this.txtUserCard.Size = new System.Drawing.Size(323, 31);
            this.txtUserCard.TabIndex = 0;
            this.txtUserCard.TextChanged += new System.EventHandler(this.txtUserCard_TextChanged);
            // 
            // txtDestinationCard
            // 
            this.txtDestinationCard.Location = new System.Drawing.Point(117, 261);
            this.txtDestinationCard.Name = "txtDestinationCard";
            this.txtDestinationCard.Size = new System.Drawing.Size(323, 31);
            this.txtDestinationCard.TabIndex = 3;
            this.txtDestinationCard.TextChanged += new System.EventHandler(this.txtDestinationCard_TextChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(117, 106);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(323, 31);
            this.txtPassword.TabIndex = 1;
            // 
            // txtSerial
            // 
            this.txtSerial.Location = new System.Drawing.Point(117, 208);
            this.txtSerial.Name = "txtSerial";
            this.txtSerial.Size = new System.Drawing.Size(323, 31);
            this.txtSerial.TabIndex = 2;
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(117, 158);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(323, 31);
            this.txtBalance.TabIndex = 4;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnSubmit.Location = new System.Drawing.Point(117, 364);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(323, 37);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "انجام عملیات";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "شماره کارت :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "کلمه عبور :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 24);
            this.label3.TabIndex = 8;
            this.label3.Text = "باقیمانده حساب :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 24);
            this.label4.TabIndex = 9;
            this.label4.Text = "کارت مقصد :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(71, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 24);
            this.label5.TabIndex = 10;
            this.label5.Text = "مبلغ :";
            // 
            // txtDestName
            // 
            this.txtDestName.Location = new System.Drawing.Point(117, 317);
            this.txtDestName.Name = "txtDestName";
            this.txtDestName.ReadOnly = true;
            this.txtDestName.Size = new System.Drawing.Size(323, 31);
            this.txtDestName.TabIndex = 11;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(47, 320);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(64, 24);
            this.name.TabIndex = 12;
            this.name.Text = "نام ذینفع :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Controls.Add(this.lblTopForm);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(465, 49);
            this.panel1.TabIndex = 13;
            // 
            // lblTopForm
            // 
            this.lblTopForm.BackColor = System.Drawing.Color.Silver;
            this.lblTopForm.Font = new System.Drawing.Font("B Nazanin", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTopForm.Location = new System.Drawing.Point(0, 0);
            this.lblTopForm.Name = "lblTopForm";
            this.lblTopForm.Size = new System.Drawing.Size(465, 49);
            this.lblTopForm.TabIndex = 0;
            this.lblTopForm.Text = "کارت به کارت";
            this.lblTopForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmCardToCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(465, 413);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.name);
            this.Controls.Add(this.txtDestName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtBalance);
            this.Controls.Add(this.txtSerial);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtDestinationCard);
            this.Controls.Add(this.txtUserCard);
            this.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmCardToCard";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "کارت به کارت";
            this.Load += new System.EventHandler(this.frmCardToCard_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtUserCard;
        private System.Windows.Forms.TextBox txtDestinationCard;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtSerial;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDestName;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTopForm;
    }
}