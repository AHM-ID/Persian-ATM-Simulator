﻿namespace ATM
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblProgramName = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnNewCustomer = new System.Windows.Forms.ToolStripButton();
            this.btnChangePassword = new System.Windows.Forms.ToolStripButton();
            this.btnCardToCard = new System.Windows.Forms.ToolStripButton();
            this.btnMobileCharge = new System.Windows.Forms.ToolStripButton();
            this.btnWithdrawal = new System.Windows.Forms.ToolStripButton();
            this.btnDeposit = new System.Windows.Forms.ToolStripButton();
            this.btnEditCustomer = new System.Windows.Forms.ToolStripButton();
            this.btnProfile = new System.Windows.Forms.ToolStripButton();
            this.btnRemoveAccount = new System.Windows.Forms.ToolStripButton();
            this.btnPrint = new System.Windows.Forms.ToolStripButton();
            this.lblUserInfo = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Date = new System.Windows.Forms.ToolStripStatusLabel();
            this.Clock = new System.Windows.Forms.ToolStripStatusLabel();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.pbLogoATMCash = new System.Windows.Forms.PictureBox();
            this.stiPrint = new Stimulsoft.Report.StiReport();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoATMCash)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Controls.Add(this.lblProgramName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1182, 61);
            this.panel1.TabIndex = 1;
            // 
            // lblProgramName
            // 
            this.lblProgramName.BackColor = System.Drawing.Color.Red;
            this.lblProgramName.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgramName.ForeColor = System.Drawing.Color.Gold;
            this.lblProgramName.Location = new System.Drawing.Point(0, 0);
            this.lblProgramName.Name = "lblProgramName";
            this.lblProgramName.Size = new System.Drawing.Size(1182, 61);
            this.lblProgramName.TabIndex = 1;
            this.lblProgramName.Text = "ATM Project";
            this.lblProgramName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNewCustomer,
            this.btnChangePassword,
            this.btnCardToCard,
            this.btnMobileCharge,
            this.btnWithdrawal,
            this.btnDeposit,
            this.btnEditCustomer,
            this.btnProfile,
            this.btnRemoveAccount,
            this.btnPrint});
            this.toolStrip1.Location = new System.Drawing.Point(0, 61);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1182, 88);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnNewCustomer
            // 
            this.btnNewCustomer.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnNewCustomer.ForeColor = System.Drawing.Color.White;
            this.btnNewCustomer.Image = global::ATM.Properties.Resources.Person;
            this.btnNewCustomer.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnNewCustomer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNewCustomer.Name = "btnNewCustomer";
            this.btnNewCustomer.Size = new System.Drawing.Size(88, 85);
            this.btnNewCustomer.Text = "افزودن کاربر";
            this.btnNewCustomer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnNewCustomer.Click += new System.EventHandler(this.btnNewCustomer_Click);
            // 
            // btnChangePassword
            // 
            this.btnChangePassword.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnChangePassword.ForeColor = System.Drawing.Color.White;
            this.btnChangePassword.Image = global::ATM.Properties.Resources.Password;
            this.btnChangePassword.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnChangePassword.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.Size = new System.Drawing.Size(111, 85);
            this.btnChangePassword.Text = "تغییر کلمه عبور";
            this.btnChangePassword.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnChangePassword.Click += new System.EventHandler(this.btnChangePassword_Click);
            // 
            // btnCardToCard
            // 
            this.btnCardToCard.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnCardToCard.ForeColor = System.Drawing.Color.White;
            this.btnCardToCard.Image = global::ATM.Properties.Resources.Card_Exchange;
            this.btnCardToCard.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnCardToCard.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCardToCard.Name = "btnCardToCard";
            this.btnCardToCard.Size = new System.Drawing.Size(98, 85);
            this.btnCardToCard.Text = "کارت به کارت";
            this.btnCardToCard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCardToCard.Click += new System.EventHandler(this.btnCardToCard_Click);
            // 
            // btnMobileCharge
            // 
            this.btnMobileCharge.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnMobileCharge.ForeColor = System.Drawing.Color.White;
            this.btnMobileCharge.Image = global::ATM.Properties.Resources.Mobile_Charge;
            this.btnMobileCharge.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnMobileCharge.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMobileCharge.Name = "btnMobileCharge";
            this.btnMobileCharge.Size = new System.Drawing.Size(72, 85);
            this.btnMobileCharge.Text = "خرید شارژ";
            this.btnMobileCharge.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMobileCharge.Click += new System.EventHandler(this.btnMobileCharge_Click);
            // 
            // btnWithdrawal
            // 
            this.btnWithdrawal.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnWithdrawal.ForeColor = System.Drawing.Color.White;
            this.btnWithdrawal.Image = global::ATM.Properties.Resources.Card;
            this.btnWithdrawal.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnWithdrawal.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnWithdrawal.Name = "btnWithdrawal";
            this.btnWithdrawal.Size = new System.Drawing.Size(89, 85);
            this.btnWithdrawal.Text = "برداشت وجه";
            this.btnWithdrawal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnWithdrawal.Click += new System.EventHandler(this.btnWithdrawal_Click);
            // 
            // btnDeposit
            // 
            this.btnDeposit.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnDeposit.ForeColor = System.Drawing.Color.White;
            this.btnDeposit.Image = ((System.Drawing.Image)(resources.GetObject("btnDeposit.Image")));
            this.btnDeposit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnDeposit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(70, 85);
            this.btnDeposit.Text = "واریز وجه";
            this.btnDeposit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDeposit.Click += new System.EventHandler(this.btnDeposit_Click);
            // 
            // btnEditCustomer
            // 
            this.btnEditCustomer.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnEditCustomer.ForeColor = System.Drawing.Color.White;
            this.btnEditCustomer.Image = global::ATM.Properties.Resources.Edit;
            this.btnEditCustomer.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnEditCustomer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditCustomer.Name = "btnEditCustomer";
            this.btnEditCustomer.Size = new System.Drawing.Size(115, 85);
            this.btnEditCustomer.Text = "ویرایش اطلاعات";
            this.btnEditCustomer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnEditCustomer.Click += new System.EventHandler(this.btnEditCustomer_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnProfile.ForeColor = System.Drawing.Color.White;
            this.btnProfile.Image = global::ATM.Properties.Resources.Profile;
            this.btnProfile.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnProfile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(107, 85);
            this.btnProfile.Text = "اطلاعات حساب";
            this.btnProfile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnRemoveAccount
            // 
            this.btnRemoveAccount.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnRemoveAccount.ForeColor = System.Drawing.Color.White;
            this.btnRemoveAccount.Image = ((System.Drawing.Image)(resources.GetObject("btnRemoveAccount.Image")));
            this.btnRemoveAccount.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnRemoveAccount.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRemoveAccount.Name = "btnRemoveAccount";
            this.btnRemoveAccount.Size = new System.Drawing.Size(129, 85);
            this.btnRemoveAccount.Text = "حذف حساب کاربری";
            this.btnRemoveAccount.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnRemoveAccount.Click += new System.EventHandler(this.btnRemoveAccount_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("B Homa", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Image = global::ATM.Properties.Resources.Print;
            this.btnPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(139, 85);
            this.btnPrint.Text = "چاپ اطلاعات کاربران";
            this.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblUserInfo
            // 
            this.lblUserInfo.BackColor = System.Drawing.SystemColors.Control;
            this.lblUserInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblUserInfo.Font = new System.Drawing.Font("B Homa", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUserInfo.FormattingEnabled = true;
            this.lblUserInfo.ItemHeight = 32;
            this.lblUserInfo.Location = new System.Drawing.Point(42, 44);
            this.lblUserInfo.Name = "lblUserInfo";
            this.lblUserInfo.Size = new System.Drawing.Size(574, 384);
            this.lblUserInfo.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.lblUserInfo);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.Font = new System.Drawing.Font("B Homa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.groupBox1.Location = new System.Drawing.Point(460, 161);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(667, 445);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "لیست کاربران";
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.statusStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Date,
            this.Clock});
            this.statusStrip1.Location = new System.Drawing.Point(0, 621);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.statusStrip1.Size = new System.Drawing.Size(1182, 32);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Date
            // 
            this.Date.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Date.ForeColor = System.Drawing.Color.Black;
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(176, 26);
            this.Date.Text = "toolStripStatusLabel1";
            // 
            // Clock
            // 
            this.Clock.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clock.ForeColor = System.Drawing.Color.Black;
            this.Clock.Name = "Clock";
            this.Clock.Size = new System.Drawing.Size(176, 26);
            this.Clock.Text = "toolStripStatusLabel1";
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Interval = 1000;
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // pbLogoATMCash
            // 
            this.pbLogoATMCash.Image = ((System.Drawing.Image)(resources.GetObject("pbLogoATMCash.Image")));
            this.pbLogoATMCash.Location = new System.Drawing.Point(12, 313);
            this.pbLogoATMCash.Name = "pbLogoATMCash";
            this.pbLogoATMCash.Size = new System.Drawing.Size(270, 250);
            this.pbLogoATMCash.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbLogoATMCash.TabIndex = 3;
            this.pbLogoATMCash.TabStop = false;
            // 
            // stiPrint
            // 
            this.stiPrint.CookieContainer = null;
            this.stiPrint.EngineVersion = Stimulsoft.Report.Engine.StiEngineVersion.EngineV2;
            this.stiPrint.ReferencedAssemblies = new string[] {
        "System.Dll",
        "System.Drawing.Dll",
        "System.Windows.Forms.Dll",
        "System.Data.Dll",
        "System.Xml.Dll",
        "Stimulsoft.Controls.Dll",
        "Stimulsoft.Base.Dll",
        "Stimulsoft.Report.Dll"};
            this.stiPrint.ReportAlias = "Report";
            this.stiPrint.ReportGuid = "f42397f4181448bf88b8b6957ca15f3f";
            this.stiPrint.ReportName = "Report";
            this.stiPrint.ReportSource = null;
            this.stiPrint.ReportUnit = Stimulsoft.Report.StiReportUnitType.Inches;
            this.stiPrint.ScriptLanguage = Stimulsoft.Report.StiReportLanguageType.CSharp;
            this.stiPrint.UseProgressInThread = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 653);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pbLogoATMCash);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "MainForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ATM";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoATMCash)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblProgramName;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnNewCustomer;
        private System.Windows.Forms.ToolStripButton btnChangePassword;
        private System.Windows.Forms.PictureBox pbLogoATMCash;
        private System.Windows.Forms.ListBox lblUserInfo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripButton btnCardToCard;
        private System.Windows.Forms.ToolStripButton btnMobileCharge;
        private System.Windows.Forms.ToolStripButton btnProfile;
        private System.Windows.Forms.ToolStripButton btnWithdrawal;
        private System.Windows.Forms.ToolStripButton btnDeposit;
        private System.Windows.Forms.ToolStripButton btnEditCustomer;
        private System.Windows.Forms.ToolStripButton btnRemoveAccount;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel Clock;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.ToolStripStatusLabel Date;
        private System.Windows.Forms.ToolStripButton btnPrint;
        private Stimulsoft.Report.StiReport stiPrint;
    }
}

