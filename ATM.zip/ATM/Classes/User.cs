﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM
{
    /// <summary>
    /// This Class Is For Create And Initialize A User Or Customer.
    /// </summary>
    public class User
    {
        private string _firstName;
        private string _lastName;
        private string _fatherName;
        private string _userName;
        private string _birthDate;
        private string _password;
        private string _phoneNumber;
        private string _homeNumber;
        private string _accountID;
        private UInt64 _accountBalance = 20;
        private string _emailAddress;
        private string _accountOpen;
        private GenderType _gender;
        private string _homeAddress;
        private string _postCode;
        private string _profilePhoto;

        /// <summary>
        /// This Property Is For Set The FirstName Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The LastName Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Fathers Name Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string FatherName 
        {
            get
            {
                return _fatherName;
            }
            set
            {
                _fatherName = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The UserName Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string UserName
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The BirthDate Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string BirthDate
        {
            get
            {
                return _birthDate;
            }
            set
            {
                _birthDate = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Password Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string Password
        {
            get
            {
                return _password;
            }
            set
            {
                _password = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Phone Number Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string PhoneNumber
        { 
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Home Number Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string HomeNumber
        {
            get
            {
                return _homeNumber;
            }
            set
            {
                _homeNumber = value;
            }
        }
        /// <summary>
        /// It`s A Method To Create A Random Account ID For New Accounts
        /// </summary>
        public void ID()
        {
            string ID = "603799";
            Random random = new Random();
            for (int i = 0; i < 10; i++)
                ID += random.Next(0, 9).ToString();
            _accountID = ID;
        }
        /// <summary>
        /// This Property Is To Get The Value Of Account ID And Its ReadOnly
        /// </summary>
        public string NewAccountID
        {
            get
            {
                return _accountID;
            }
        }
        /// <summary>
        /// This Property Is For Set The AccountID Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string AccountID
        {
            get
            {
                return _accountID;
            }
            set
            {
                _accountID = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The AccountBalance Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public UInt64 AccountBalance
        {
            get
            {
                return _accountBalance;
            }
            set
            {
                _accountBalance = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The EmailAddress Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string EmailAddress
        {
            get
            {
                return _emailAddress;
            }
            set
            {
                _emailAddress = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The AccountOpen Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string AccountOpen
        {
            get
            {
                return _accountOpen;
            }
            set
            {
                _accountOpen = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Gender Of User Or Customer And Turn It Back If We Call the Property.
        /// It Returns 0 For Males And 1 For Females.
        /// </summary>
        public GenderType Gender
        {
            get
            {
                return _gender;
            }
            set
            {
                _gender = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Home Address Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string HomeAddress 
        {
            get
            {
                return _homeAddress;
            }
            set
            {
                _homeAddress = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Post Code Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string PostCode
        {
            get
            {
                return _postCode;
            }
            set
            {
                _postCode = value;
            }
        }
        /// <summary>
        /// This Property Is For Set The Profile Picture Of User Or Customer And Turn It Back If We Call the Property
        /// </summary>
        public string ProfilePhoto 
        { 
            get
            {
                return _profilePhoto;
            }
            set
            {
                _profilePhoto = value;
            }
        }
    }
}
