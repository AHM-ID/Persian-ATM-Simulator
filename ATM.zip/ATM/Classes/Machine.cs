﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.IO;

namespace ATM
{
    public class Machine : User
    {
        List<string> user;
        public Machine()
        {
            user = new List<string>();
        }
        /// <summary>
        /// This Method Is For CardToCard Operation
        /// the Method is Get The ID`s Of Two Sides And The Amount Of Money And Substract The Amount From User Balance And Add It To Destination Card.
        /// </summary>
        /// <param name="UserID">The User Account ID</param>
        /// <param name="DestinationID">The Destination Account ID</param>
        /// <param name="Amount">Amount Of Money To Transfer</param>
        /// <returns>it Returns A bool Which If Operation Is Succeed true and else returns false</returns>
        public bool CardToCard(string UserID, string DestinationID, UInt64 Amount)
        {
            int UserIndex = UserRepository.customersList.FindIndex(user => user.AccountID == UserID);
            int DestIndex = UserRepository.customersList.FindIndex(user => user.AccountID == DestinationID);
            try
            {
                UserRepository.customersList[UserIndex].AccountBalance -= Amount;
                UserRepository.customersList[DestIndex].AccountBalance += Amount;
                WriteJson();
                return true;
            }
            catch { return false; }
        }
        /// <summary>
        /// This Method Is For MobileCharge Operation
        /// the Method Is Get The UserID and Amount Of Money To Charge Then Substract The Money From Account of User.
        /// </summary>
        /// <param name="UserID">The User Account ID</param>
        /// <param name="Amount">The Amount Of Money</param>
        /// <returns>it Returns The String Of Charge Code</returns>
        public string MobileCharge(string UserID, UInt64 Amount)
        {
            int UserIndex = -1;
            if (UserRepository.customersList.Exists(user => user.AccountID == UserID))
                UserIndex = UserRepository.customersList.FindIndex(user => user.AccountID == UserID);
            try
            {
                UserRepository.customersList[UserIndex].AccountBalance -= Amount;
                WriteJson();
                string Charge = "IR144";
                Random random = new Random();
                for (int i = 0; i < 10; i++)
                    Charge += random.Next(0, 9).ToString();
                return Charge;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// This Method Is For Withdrawal Money Operation
        /// the Method Get A ID From User And Amount Of Money He Want To Get And Give Him That Money then Substract the Money From Account.
        /// </summary>
        /// <param name="UserID">The User Account ID</param>
        /// <param name="Amount">The Amount Of Money</param>
        /// <returns>it Returns A bool Which If Operation Is Succeed true and else returns false</returns>
        public bool WithdrawalMoney(string UserID, UInt64 Amount)
        {
            int UserIndex = -1;
            if (UserRepository.customersList.Exists(user => user.AccountID == UserID))
                UserIndex = UserRepository.customersList.FindIndex(user => user.AccountID == UserID);
            try
            {
                UserRepository.customersList[UserIndex].AccountBalance -= Amount;
                WriteJson();
                return true;
            }
            catch { return false; }
        }
        /// <summary>
        /// This Method Is For Deposit Money Operation
        /// the Method Is Get UserID and Amount Of Money And Add Money To User Account.
        /// </summary>
        /// <param name="UserID">The User Account ID</param>
        /// <param name="Amount">The Amount Of Money</param>
        /// <returns>it Returns A bool Which If Operation Is Succeed true and else returns false</returns>
        public bool DepositMoney(string UserID, UInt64 Amount)
        {
            int UserIndex = -1;
            if (UserRepository.customersList.Exists(user => user.AccountID == UserID))
                UserIndex = UserRepository.customersList.FindIndex(user => user.AccountID == UserID);
            try
            {
                UserRepository.customersList[UserIndex].AccountBalance += Amount;
                WriteJson();
                return true;
            }
            catch { return false; }
        }
        /// <summary>
        /// This Method Is Check Email And Validate Email
        /// </summary>
        /// <param name="email">Email String Input</param>
        /// <returns>It Returns True For Valid Emails And False For Invalid Emails</returns>
        public bool EmailCheck(string email)
        {
            int Counter = email.Split('@').Length;
            if (Counter == 2)
            {
                email = email.Remove(0, email.IndexOf('@'));
                Counter = email.Split('.').Length;
                if (Counter > 1)
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        /// <summary>
        /// This Method Is Check The Strength of Password
        /// Safe Password Has At Least A Upper A Lower A Number A Symbol and 8 Charachters Length
        /// </summary>
        /// <param name="password">The Password String Input</param>
        /// <returns>It Returns true For Safe Password and false For Unsafe Password</returns>
        public bool PasswordSecurity(string password)
        {
            if (password.Length >= 8)
            {
                if (password.Any(char.IsUpper))
                {
                    if (password.Any(char.IsLower))
                    {
                        if (password.Any(char.IsNumber))
                        {
                            if (password.Any(char.IsSymbol) || password.Contains('@') || password.Contains('&') || password.Contains('?') || password.Contains('!') || password.Contains(';'))
                                return true;
                            else
                                return false;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        /// <summary>
        /// This Method Will Remove The Account Of User if He Wants Or input Password Wrong 3 Times
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns>Returnt True If Removing Operation Is Succesful and False for UnSuccesful Operation</returns>
        public bool RemoveAccount(string UserID)
        {
            try
            {
                if(UserRepository.customersList.Exists(user => user.AccountID == UserID))
                {
                    int index = UserRepository.customersList.FindIndex(user => user.AccountID == UserID);
                    UserRepository.customersList.RemoveAt(index);
                    WriteJson();
                }
                return true;
            }
            catch { return false; }
        }
        /// <summary>
        /// Write the Information Of Users Which is Stored in List Of Users in a JSON File
        /// </summary>
        internal void WriteJson()
        {
            string json = JsonConvert.SerializeObject(UserRepository.customersList.ToArray());
            UserRepository.customersList.Clear();
            File.WriteAllText(Application.StartupPath.ToString() + "Data.txt", json);
        }
        /// <summary>
        /// Read the Information Of Users Which is Stored in JSON File and Fill List Of User With it
        /// </summary>
        internal void ReadJson()
        {
            using (StreamReader reader = new StreamReader(Application.StartupPath + "Data.txt"))
            {
                string json = reader.ReadToEnd();
                UserRepository.customersList.Clear();
                UserRepository.customersList = JsonConvert.DeserializeObject<List<User>>(json);
            }
        }
    }
}
