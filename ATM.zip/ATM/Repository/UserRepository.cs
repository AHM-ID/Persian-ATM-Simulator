﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM
{
    public static class UserRepository
    {
        public static List<User> customersList = new List<User>();
    }
}
